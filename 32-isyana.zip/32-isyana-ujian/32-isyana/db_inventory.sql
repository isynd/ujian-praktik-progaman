-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_inventory
CREATE DATABASE IF NOT EXISTS `db_inventory` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_inventory`;

-- Dumping structure for table db_inventory.barang
CREATE TABLE IF NOT EXISTS `barang` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `spesifikasi` varchar(200) DEFAULT NULL,
  `stok` int(5) DEFAULT '0',
  `lokasi` varchar(200) DEFAULT NULL,
  `kategori_id` int(5) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `kategori_id` (`kategori_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table db_inventory.barang: ~15 rows (approximately)
/*!40000 ALTER TABLE `barang` DISABLE KEYS */;
REPLACE INTO `barang` (`id`, `spesifikasi`, `stok`, `lokasi`, `kategori_id`) VALUES
	(1, '2 PK', 2, 'Lab.Pemrograman', 1),
	(2, '2 PK', 2, 'Lab PnP', 1),
	(3, '2 PK', 2, 'Lab LAN', 1),
	(4, '2 PK', 2, 'Lab WAN', 1),
	(5, 'AMP RJ-45', 5, 'Lab.Pemrograman', 2),
	(6, 'RJ-45', 2, 'Lab.Pemrograman', 4),
	(7, 'Gigabit', 6, 'Lab.Pemrograman', 3),
	(8, 'Core i3', 10, 'Lab.PnP', 5),
	(9, 'Core i3', 5, 'Lab.WAN', 5),
	(10, 'Core i3', 10, 'Lab.LAN', 5),
	(11, 'Core i3', 10, 'Lab.Pemrograman', 6),
	(12, 'Mouse', 20, 'Lab.Pemrograman', 7),
	(13, 'Keyboard', 25, 'Lab.PnP', 8),
	(14, 'Proyektor', 1, 'Lab.LAN', 9),
	(15, 'Proyektor', 1, 'Lab.PnP', 9);
/*!40000 ALTER TABLE `barang` ENABLE KEYS */;

-- Dumping structure for table db_inventory.barangkeluar
CREATE TABLE IF NOT EXISTS `barangkeluar` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tgl_keluar` date DEFAULT NULL,
  `jumlah` int(15) NOT NULL DEFAULT '0',
  `barang_id` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barang_id` (`barang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table db_inventory.barangkeluar: ~15 rows (approximately)
/*!40000 ALTER TABLE `barangkeluar` DISABLE KEYS */;
REPLACE INTO `barangkeluar` (`id`, `tgl_keluar`, `jumlah`, `barang_id`) VALUES
	(1, '2022-07-28', 5, 6),
	(2, '2022-06-15', 2, 6),
	(3, '2022-07-20', 1, 1),
	(4, '2022-05-26', 15, 5),
	(5, '2022-01-10', 2, 9),
	(6, '2022-04-08', 20, 8),
	(7, '2021-12-27', 10, 7),
	(8, '2022-02-27', 2, 6),
	(9, '2022-03-27', 5, 5),
	(10, '2021-06-19', 1, 9),
	(11, '2020-07-05', 2, 1),
	(12, '2021-11-28', 7, 5),
	(13, '2021-10-17', 2, 6),
	(14, '2022-04-23', 6, 8),
	(15, '2022-02-27', 2, 1);
/*!40000 ALTER TABLE `barangkeluar` ENABLE KEYS */;

-- Dumping structure for table db_inventory.barangmasuk
CREATE TABLE IF NOT EXISTS `barangmasuk` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tgl_masuk` date DEFAULT NULL,
  `jumlah` int(5) DEFAULT NULL,
  `barang_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barang_id` (`barang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table db_inventory.barangmasuk: ~14 rows (approximately)
/*!40000 ALTER TABLE `barangmasuk` DISABLE KEYS */;
REPLACE INTO `barangmasuk` (`id`, `tgl_masuk`, `jumlah`, `barang_id`) VALUES
	(1, '2022-07-28', 5, 6),
	(2, '2022-05-24', 1, 1),
	(3, '2021-07-30', 3, 3),
	(4, '2021-09-29', 2, 6),
	(5, '2022-05-31', 1, 9),
	(6, '2021-10-15', 2, 5),
	(7, '2021-12-08', 10, 7),
	(8, '2020-04-16', 2, 1),
	(9, '2022-03-22', 5, 8),
	(10, '2022-01-29', 1, 9),
	(11, '2022-03-27', 1, 6),
	(12, '2022-04-23', 3, 6),
	(13, '2022-07-06', 3, 8),
	(14, '2022-03-08', 9, 7);
/*!40000 ALTER TABLE `barangmasuk` ENABLE KEYS */;

-- Dumping structure for table db_inventory.kategori
CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(200) DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table db_inventory.kategori: ~15 rows (approximately)
/*!40000 ALTER TABLE `kategori` DISABLE KEYS */;
REPLACE INTO `kategori` (`id`, `kategori`, `keterangan`) VALUES
	(1, 'Pendingin Ruangan', 'M'),
	(2, 'Alat Praktik Jaringan Komputer', 'A'),
	(3, 'Bahan Praktik Jaringan Komputer', 'BHP'),
	(4, 'Bahan Praktik Jaringan Komputer', 'BTHP'),
	(5, 'Alat Pembelajaran', 'L'),
	(6, 'Bahan Praktik IOT', 'T'),
	(7, 'Alat Kebersihan', 'K'),
	(8, 'Alat Pembelajaran', 'S'),
	(9, 'Bahan Praktik Jaringan Komputer', 'BHTP'),
	(10, 'Bahan Praktik IOT', 'O'),
	(11, 'Alat Pembelajaran', 'P'),
	(12, 'Bahan Praktik Jaringan Komputer', 'BPJK'),
	(13, 'Alat Pembelajaran', 'B'),
	(14, 'Bahan Praktik IOT', 'I'),
	(15, 'Alat Pembelajaran', 'J');
/*!40000 ALTER TABLE `kategori` ENABLE KEYS */;

-- Dumping structure for table db_inventory.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_nama` varchar(100) DEFAULT NULL,
  `user_username` varchar(100) DEFAULT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table db_inventory.user: ~1 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
REPLACE INTO `user` (`user_id`, `user_nama`, `user_username`, `user_password`) VALUES
	(1, 'admin inventory', 'admin', '827ccb0eea8a706c4c34a16891f84e7b');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
