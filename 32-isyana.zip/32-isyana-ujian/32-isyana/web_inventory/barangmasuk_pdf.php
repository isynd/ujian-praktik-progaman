
<?php
	//mengakses file konfigurasi awal dompdf
	require_once("../dompdf/autoload.inc.php");
	
	//membuat namespace 
	use Dompdf\Dompdf;
	
	//membuat object untuk mengelol file pdf
	$demoPDF = new Dompdf();
	
	//menyiapkan data
	//data bertipe HTML
	//biasanya disimpan dalam sebuat variabel
	
	//skenario menampilkan tabel barang
	// daftar barang
	include "../db_connect.php";
	
	//membuat query untuk akses tabel barang all
	$qBarangMasuk = "SELECT * FROM barangmasuk";
	
	//menjalankan query
	$rsBarangMasuk = $myConn->query($qBarangMasuk);
	
	//menampilkan jumlah record yang didapat
	//echo $rsBarang->num_rows;
	
	$data = "<center>
    <h4>LAPORAN BARANG MASUK</h4>
	<h5>Admin Inventory</h5>
  </center>";

	$data .= '<html>
	<head>
	<style>
	table, td, th {
  		border: 2px solid black;
		}

	table {
	border-collapse: collapse;
	width: 100%;
	}

	th {
		text-align: center;
		}

	td {
	height: 10px;
	vertical-align: left;
	}
	</style>
	</head>
	<table>';
	$data .= "<thead>
	<tr>
    <th>NO</th>
    <th>TANGGAL MASUK</th>
    <th>JUMLAH</th>
    <th>BARANG ID</th>
	</tr>
  </thead>";
	// $data .= "<tr>";
	// $data .= "<td>No</td><td>Kategori</td><td>Keterangan</td>";
	// $data .= "</tr>";

	
	while($row = $rsBarangMasuk->fetch_assoc()){
		$data .= "<tr>";
			$data .= "<td>".$row['id']."</td>";
			$data .= "<td>".$row['tgl_masuk']."</td>";
			$data .= "<td>".$row['jumlah']."</td>";
            $data .= "<td>".$row['barang_id']."</td>";
		$data .= "</tr>";
	}
	$data .= "</table>";
	
	
	//data akan dibuat pdf
	$demoPDF->loadHtml($data);	
	$demoPDF->setPaper('A4', 'potrait');
	$demoPDF->render();
	
	//memastikan file pdf bisa dibuka di browser chrome
	ob_end_clean();
	$demoPDF->stream('Barang Masuk.pdf',array("Attachment" => 0));

?>
</body>
</html>
