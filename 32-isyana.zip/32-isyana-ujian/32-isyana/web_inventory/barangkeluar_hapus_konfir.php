<?php include 'header.php'; ?>

<div class="content-wrapper">

  <section class="content-header">
    
  </section>

  <section class="content">
    <div class="row">

      <section class="container-fluid"> 
        <div class="card shadow mb-6">
          <div class="card-header py-2">
            <div class="d-sm-flex align-items-center justify-content-between mb-1">
              <h6 class="h3 font-weight-bold text-primary">Yakin Ingin Menghapus Barang Keluar ?</h6>                    
            </div>
 
          </div>
          <div class="card-body">
            <p>Dengan menghapus, semua data yang berhubungan dengan barang akan dihapus dari database.</p>
            
             <?php 
             $idd = $_GET['id']; 
             ?> 
            <a href="barangkeluar_hapus.php?id=<?php echo $idd; ?>" class="btn btn-success btn-sm pull-right"><i class="fa fa-check"></i> &nbsp Hapus</a>
            <a href="barangkeluar.php" class="btn btn-info btn-sm pull-right"><i class="fa fa-reply"></i> &nbsp Kembali</a>                
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>