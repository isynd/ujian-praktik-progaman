<?php 
include '../db_connect.php';
$spesifikasi = $_POST['spesifikasi'];
$stok = $_POST['stok'];
$lokasi = $_POST['lokasi'];
$kategori_id = $_POST['kategori_id'];

$qInsertBarang = "insert into barang
                    values (NULL,
                    '$spesifikasi',
                    '$stok',
                    '$lokasi',
                    '$kategori_id')";
                    

$myConn->query($qInsertBarang);
	

//mysqli_query($koneksi, "insert into barang values (NULL,'$nama ','$spesifikasi','$lokasi','$kondisi','$jumlah','$sumber_dana','$keterangan','$jenis')");
header("location:barang.php");