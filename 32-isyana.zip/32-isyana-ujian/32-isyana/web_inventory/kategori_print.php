<!DOCTYPE html>
 <html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Print Laporan Kategori</title>
  <link rel="stylesheet" href="../assets/bower_components/bootstrap/dist/css/bootstrap.min.css">

</head>
<style>
table, td, th {
  border: 2px solid black;
}
table {
  border-collapse: collapse;
  width: 100%;
}
</style>
<body>

  <center>
    <h4>Laporan kategori</h4>
    <h5>Admin Inventory</h5>
  </center>

  <?php include "../db_connect.php"; ?>
  <table class="table" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kategori</th>
                                            <th>Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                 $no=1;
                $data = $myConn->query("SELECT * FROM kategori");
                 while($d = mysqli_fetch_array($data)){
                   ?>
                   <tr>
                     <td><?php echo $no++; ?></td>
                     <td><?php echo $d['kategori']; ?></td>
                     <td><?php echo $d['keterangan']; ?></td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
                </table>

<script>

  window.print();
  $(document).ready(function(){

  });
</script>

</body>
</html>
