<?php 
include '../db_connect.php';
$spesifikasi = $_POST['spesifikasi'];
$stok = $_POST['stok'];
$lokasi = $_POST['lokasi'];
$kategori_id = $_POST['kategori_id'];

$qUpdateBarang = "update barang
                    spesifikasi='$spesifikasi', 
                    stok='$stok',
                    lokasi='$lokasi',
                    kategori_id='$kategori_id'
                   ";
//jalankan query
$myConn->query($qUpdateBarang);                    

//mysqli_query($koneksi, "update barang set barang_nama='$nama', barang_spesifikasi='$spesifikasi', barang_lokasi='$lokasi', barang_kondisi='$kondisi', barang_jumlah='$jumlah', barang_sumber_dana='$sumber_dana', barang_keterangan='$keterangan', barang_jenis='$jenis' where barang_id='$id'");
header("location:barang.php");