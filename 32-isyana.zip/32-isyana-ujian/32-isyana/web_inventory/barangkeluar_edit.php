<?php include 'header.php'; ?>

<div class="content-wrapper">

  

  <section class="content">
    <div class="row">
    <section class="container-fluid">       
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h6 class="h3 mb-0 font-weight-bold text-success"><center>Edit Barang Keluar</center></h6>
              <a href="barangkeluar.php" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm"><i class="fa fa-reply"></i> &nbsp Kembali</a>               
            </div>
            
 
          </div>
          <div class="card-body">
            <form action="barangkeluar_update.php" method="post">
            <?php 
            include '../db_connect.php';
              $id = $_GET['id'];              
              $data = $myConn->query("SELECT * FROM barangkeluar");
              while($d = mysqli_fetch_array($data)){
                ?>
              
              <div class="form-group">
                <label>Tanggal Keluar</label>
                <input type="hidden" name="id" value="<?php echo $d['id'] ?>">
                <input type="date" class="form-control" name="tgl_keluar" required="required" placeholder="Masukkan tanggal .." value="<?php echo $d['tgl_masuk'] ?>">
              </div>

              <div class="form-group">
                <label>Jumlah</label>
                <input type="number" class="form-control" name="jumlah" required="required" placeholder="Masukkan jumlah .." value="<?php echo $d['jumlah'] ?>">
              </div>
              
              <div class="form-group">
                      <label>Barang ID</label>
                      <select class="form-control" name="barang_id" required="required">
                      <option value=""> - Pilih Barang - </option>
                        <?php 
                        include 'db_connect.php';
                       
                        $data = $myConn->query("SELECT * FROM barang");
                         while($d = mysqli_fetch_array($data)){
                          ?>
                          <option value="<?php echo $d['id']; ?>"><?php echo $d['spesifikasi']; ?></option>
                          <?php 
                        }
                        ?>
                      </select>
                    </div>

              <div class="form-group">
                <input type="submit" class="btn btn-sm btn-primary" value="Simpan">
              </div>
              <?php 
              }
              ?>
            </form>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>