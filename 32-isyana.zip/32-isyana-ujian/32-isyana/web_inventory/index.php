<?php include 'header.php'; ?>
<!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
<h1 class="h3 mb-2 text-info">DASHBOARD</h1>
</div>

<!-- Content Row -->
<div class="row">

     <!-- Earnings (Monthly) Card Example -->
     <div class="col-lg-3 col-xs-6">
        <div class="card border-left-success shadow h-100 py-2", style="border-left: .25rem solid #228B22!important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1", style="color: #228B22!important;">
                            TABEL KATEGORI</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><a href="kategori.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a></div>
                    </div>
                    <div class="col-auto">
                        <i class="far fa-calendar-alt fa-2x text-red-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-3 col-xs-6">
        <div class="card border-left-success shadow h-100 py-2" , style="border-left: .25rem solid #DC143C!important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1", style="color: #DC143C!important;">
                            TABEL BARANG</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><a href="barang.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-columns fa-2x text-red-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-3 col-xs-6">
        <div class="card border-left-primary shadow h-100 py-2", style="border-left: .25rem solid #191970!important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1", style="color: #191970!important;">
                            BARANG MASUK
                        </div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><a href="barangmasuk.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                    <i class="far fa-calendar-plus fa-2x text-red-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-lg-3 col-xs-6">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            BARANG KELUAR</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><a href="barangmasuk.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a></div>
                    </div>
                    <div class="col-auto">
                    <i class="far fa-calendar-minus fa-2x text-red-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'footer.php'; ?>