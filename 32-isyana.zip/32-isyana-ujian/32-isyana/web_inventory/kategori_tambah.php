<?php include 'header.php'; ?>
<?php include "../db_connect.php"; ?>

<div class="content-wrapper">
        <section class="content">
    <div class="row">
      <section class="container-fluid">       
        <div class="card shadow mb-4">

          <div class="card-header py-3">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h6 class="h3 mb-0 font-weight-bold text-success"><center>Tambah Kategori</center></h6>
              <a href="kategori.php" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm"><i class="fa fa-reply"></i> &nbsp Kembali</a>               
            
            </div>
 
          </div>
          <div class="card-body">
            <form action="kategori_act.php" method="post">
              <div class="form-group">
                <label>Kategori</label>
                <input type="hidden" name="id">
                <input type="text" class="form-control" name="kategori" required="required" placeholder="Masukkan kategori ..">
              </div>

              <div class="form-group">
                  <label>Keterangan</label>
                  <select class="form-control" name="jenis" required="required">
                    <option value=""> - Pilih Kategori - </option>
                    <option value="M">M</option>
                    <option value="A">A</option>
                    <option value="BHP">BHP</option>
                    <option value="BTHP">BTHP</option>
                  </select>
                </div>

                <div class="form-group">
                  <input type="submit" class="btn btn-sm btn-primary" value="Simpan">
                </div>
            </form>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>