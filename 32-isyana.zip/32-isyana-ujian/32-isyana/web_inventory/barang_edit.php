<?php include 'header.php'; ?>


<div class="content-wrapper">
    <section class="content">
    <div class="row">
      <section class="container-fluid">       
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h6 class="h3 mb-0 font-weight-bold text-success"><center>Edit Barang</center></h6>
              <a href="barang.php" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm"><i class="fa fa-reply"></i> &nbsp Kembali</a>               
            </div>
 
          </div>
          <div class="card-body">
            <form action="barang_update.php" method="post">
                <?php 
               $id = $_GET['id'];              
               $qEditBarang = "SELECT * FROM barang WHERE id='$id'";
               $data = $myConn->query($qEditBarang);
              while($d=$data->fetch_array()){
                ?>
                <div class="form-group">
                  <label>Spesifikasi</label>
                  <input type="text" class="form-control" name="spesifikasi" required="required" placeholder="Masukkan spesifikasi .." value="<?php echo $d['spesifikasi'] ?>">
                </div>
                <div class="form-group">
                  <label>Stok</label>
                  <input type="text" class="form-control" name="stok" required="required" placeholder="Masukkan stok .." value="<?php echo $d['stok'] ?>">
                </div>

                <div class="form-group">
                  <label>Lokasi</label>
                  <input type="text" class="form-control" name="lokasi" required="required" placeholder="Masukkan lokasi .." value="<?php echo $d['lokasi'] ?>">
                </div>

                <div class="form-group">
                  <label>Kategori ID</label>
                  <input type="number" class="form-control" name="kategori_id" required="required" placeholder="Masukkan kategori id .." value="<?php echo $d['kategori_id'] ?>">
                </div>

                <div class="form-group">
                  <input type="submit" class="btn btn-sm btn-primary" value="Simpan">
                </div>
                <?php 
              }
              ?>
            </form>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>