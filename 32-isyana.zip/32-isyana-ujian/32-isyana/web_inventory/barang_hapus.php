<?php 
    include '../db_connect.php';
    $id = $_GET['id'];

    $qDellBarang="delete from barang where barang_id='$id'";
    $myConn->query($qDellBarang);

    $qDellBarangMasuk="delete from barang_masuk where bm_id_barang='$id'";
    $myConn->query($qDellBarangMasuk);

    $qDellBarangKeluar="delete from barang_masuk where bm_id_barang='$id'";
    $myConn->query($qDellBarangKeluar);

header("location:barang.php");
